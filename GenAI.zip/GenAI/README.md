This is my first step towards learning the GenAI by making basic and fundamental concepts clear through implementing them.
